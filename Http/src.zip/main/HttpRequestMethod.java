package main;

public enum HttpRequestMethod {
    GET,
    PUT,
    POST,
    OPTIONS,
    HEAD,
    DELETE
}
