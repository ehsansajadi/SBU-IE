const Screen = ({ text }) => {
  return <div className="screen">{text}</div>;
};

export default Screen;
